package com.cognizant.auditauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditManagementAuthorizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
