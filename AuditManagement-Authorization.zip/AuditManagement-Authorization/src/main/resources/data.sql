insert into users (id, password, user_name) values (1, 'admin1234', 'admin');
insert into users (id, password, user_name) values (2, 'user1234', 'user1');
insert into users (id, password, user_name) values (3, 'user5678', 'user2');